Run the application:
Task1: ./gradlew run --args="1"
Task2" ./gradlew run --args="2"
Task3: ./gradlew run --args="3 src/main/resources/example1.xml"
Task4: ./gradlew run --args="4 src/main/resources/example2.xml"
Task5: ./gradlew run --args="5 src/main/resources/example3.xml"

All Tasks are completed.
I added the generated the images under the output folder. 