package com.example.raytracer;

public class Camera {
    private Vec3 position;
    private Vec3 lookat;
    private Vec3 up;
    private float horizontalFov;
    private int imageWidth;
    private int imageHeight;
    private int maxBounces;

    public Camera(Vec3 position, Vec3 lookat, Vec3 up, float horizontalFov, int imageWidth, int imageHeight, int maxBounces) {
        this.position = position;
        this.lookat = lookat;
        this.up = up;
        this.horizontalFov = horizontalFov;
        this.imageWidth = imageWidth;
        this.imageHeight = imageHeight;
        this.maxBounces = maxBounces;
    }

    public Ray getRayToPixel(int x, int y) {
        float aspectRatio = (float) imageWidth / (float) imageHeight;
        float fovx = (float) Math.tan(Math.toRadians(horizontalFov / 2));
        float fovy = fovx / aspectRatio;

        float xn = (x + 0.5f) / imageWidth;
        float yn = (y + 0.5f) / imageHeight;

        float xi = (2 * xn - 1) * fovx;
        float yi = (1 - 2 * yn) * fovy;  // Flip y for correct image orientation

        Vec3 direction = new Vec3(xi, yi, -1).normalize();
        return new Ray(position, direction);
    }

    public int getImageWidth() {
        return imageWidth;
    }

    public int getImageHeight() {
        return imageHeight;
    }

    public int getMaxBounces() {
        return maxBounces;
    }

    public void setPosition(Vec3 position) {
        this.position = position;
    }
}
