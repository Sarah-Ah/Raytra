package com.example.raytracer;

public class Material {
    private Color color;
    private float ka;  // Ambient reflection coefficient
    private float kd;  // Diffuse reflection coefficient
    private float ks;  // Specular reflection coefficient
    private float exponent;  // Phong exponent

    public Material(Color color, float ka, float kd, float ks, float exponent) {
        this.color = color;
        this.ka = ka;
        this.kd = kd;
        this.ks = ks;
        this.exponent = exponent;
    }

    public Color getColor() {
        return color;
    }

    public float getKa() {
        return ka;
    }

    public float getKd() {
        return kd;
    }

    public float getKs() {
        return ks;
    }

    public float getExponent() {
        return exponent;
    }
}
