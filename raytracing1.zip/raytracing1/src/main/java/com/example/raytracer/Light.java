package com.example.raytracer;

public abstract class Light {
    protected Color color;

    public Light(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }
}

class AmbientLight extends Light {
    public AmbientLight(Color color) {
        super(color);
    }
}

class PointLight extends Light {
    private Vec3 position;

    public PointLight(Color color, Vec3 position) {
        super(color);
        this.position = position;
    }

    public Vec3 getPosition() {
        return position;
    }
}
