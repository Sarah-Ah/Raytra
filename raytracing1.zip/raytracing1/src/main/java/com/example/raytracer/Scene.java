package com.example.raytracer;

import java.util.ArrayList;
import java.util.List;

public class Scene {
    private String outputFile;
    private Color backgroundColor;
    private Camera camera;
    private List<Sphere> spheres = new ArrayList<>();
    private List<Light> lights = new ArrayList<>();

    public String getOutputFile() {
        return outputFile;
    }

    public void setOutputFile(String outputFile) {
        this.outputFile = outputFile;
    }

    public Color getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(Color backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public Camera getCamera() {
        return camera;
    }

    public void setCamera(Camera camera) {
        this.camera = camera;
    }

    public void addSphere(Sphere sphere) {
        spheres.add(sphere);
    }

    public List<Sphere> getSpheres() {
        return spheres;
    }

    public void addLight(Light light) {
        lights.add(light);
    }

    public List<Light> getLights() {
        return lights;
    }
}
