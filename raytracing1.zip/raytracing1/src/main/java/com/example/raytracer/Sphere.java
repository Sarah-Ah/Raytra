package com.example.raytracer;

public class Sphere {
    private Vec3 center;
    private float radius;
    private Material material;

    public Sphere(Vec3 center, float radius, Material material) {
        this.center = center;
        this.radius = radius;
        this.material = material;
    }

    public Vec3 getCenter() {
        return center;
    }

    public float getRadius() {
        return radius;
    }

    public Material getMaterial() {
        return material;
    }

    public boolean intersect(Ray ray, float[] t) {
        // Implementation of the ray-sphere intersection
        Vec3 oc = ray.getOrigin().subtract(center);
        float a = ray.getDirection().dot(ray.getDirection());
        float b = 2.0f * oc.dot(ray.getDirection());
        float c = oc.dot(oc) - radius * radius;
        float discriminant = b * b - 4 * a * c;

        if (discriminant > 0) {
            float t1 = (-b - (float) Math.sqrt(discriminant)) / (2.0f * a);
            float t2 = (-b + (float) Math.sqrt(discriminant)) / (2.0f * a);
            t[0] = (t1 < t2) ? t1 : t2;
            return true;
        }
        return false;
    }
}
