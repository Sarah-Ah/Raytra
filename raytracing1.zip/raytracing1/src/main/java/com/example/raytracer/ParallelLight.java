package com.example.raytracer;

public class ParallelLight extends Light {
    private Vec3 direction;

    public ParallelLight(Color color, Vec3 direction) {
        super(color);
        this.direction = direction.normalize(); // Ensure the direction is normalized
    }

    public Vec3 getDirection() {
        return direction;
    }

    @Override
    public String toString() {
        return "ParallelLight{" +
                "color=" + getColor() +
                ", direction=" + direction +
                '}';
    }
}
