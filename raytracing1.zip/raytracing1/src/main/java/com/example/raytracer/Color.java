package com.example.raytracer;

public class Color {
    private float r, g, b;

    public Color(float r, float g, float b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public Color add(Color other) {
        return new Color(this.r + other.r, this.g + other.g, this.b + other.b);
    }

    public Color multiply(Color other) {
        return new Color(this.r * other.r, this.g * other.g, this.b * other.b);
    }

    public Color multiply(float factor) {
        return new Color(this.r * factor, this.g * factor, this.b * factor);
    }

    public java.awt.Color toAwtColor() {
        return new java.awt.Color(clamp(r), clamp(g), clamp(b));
    }

    private float clamp(float value) {
        return Math.max(0, Math.min(1, value));
    }
    public Color scale(float scalar) {
        return new Color(this.r * scalar, this.g * scalar, this.b * scalar);
    }
}
