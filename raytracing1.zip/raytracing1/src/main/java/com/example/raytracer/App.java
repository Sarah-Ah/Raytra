package com.example.raytracer;

public class App {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java App <task> [<input-file>]");
            System.out.println("Tasks:");
            System.out.println("1: Output a valid black image file");
            System.out.println("2: Output an image with spheres after ray tracing them");
            System.out.println("3: Render scene from XML file");
            System.out.println("4: Render scene with Phong illumination");
            System.out.println("5: Render scene with shadows");
            return;
        }

        int task = Integer.parseInt(args[0]);
        RayTracer rayTracer = new RayTracer();

        if (task == 1) {
            // Task 1: Output a valid black image file
            rayTracer.renderBlackImage();
        } else if (task == 2) {
            // Task 2: Output an image with spheres after ray tracing them
            rayTracer.renderSpheresScene();
        } else if (task == 3) {
            // Task 3: Render scene from XML file
            if (args.length < 2) {
                System.out.println("Please provide the path to the XML file.");
                return;
            }
            String filePath = args[1];
            rayTracer.renderFromXML(filePath);
        } else if (task == 4) {
            // Task 4: Render scene with Phong illumination
            if (args.length < 2) {
                System.out.println("Please provide the path to the XML file.");
                return;
            }
            String filePath = args[1];
            rayTracer.renderFromXML(filePath);
        } else if (task == 5) {
            // Task 5: Render scene with shadows
            if (args.length < 2) {
                System.out.println("Please provide the path to the XML file.");
                return;
            }
            String filePath = args[1];
            rayTracer.renderFromXML(filePath);
        } else {
            System.out.println("Invalid task.");
        }
    }
}
