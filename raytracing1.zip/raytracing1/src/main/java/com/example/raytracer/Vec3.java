package com.example.raytracer;

public class Vec3 {
    private float x, y, z;

    public Vec3(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    public Vec3(double x, double y, double z) {
        this((float) x, (float) y, (float) z);
    }
    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getZ() {
        return z;
    }
    public Vec3 negate() {return new Vec3(-x, -y, -z);}
    public Vec3 subtract(Vec3 v) {
        return new Vec3(x - v.x, y - v.y, z - v.z);
    }

    public Vec3 add(Vec3 v) {
        return new Vec3(x + v.x, y + v.y, z + v.z);
    }

    public Vec3 scale(float s) {
        return new Vec3(x * s, y * s, z * s);
    }

    public float dot(Vec3 v) {
        return x * v.x + y * v.y + z * v.z;
    }

    public float length() {
        return (float) Math.sqrt(x * x + y * y + z * z);
    }

    public Vec3 normalize() {
        float len = length();
        return new Vec3(x / len, y / len, z / len);
    }
    public Vec3 reflect(Vec3 normal) {
        return this.subtract(normal.scale(2 * this.dot(normal)));
    }

}
