package com.example.raytracer;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.File;

public class SceneReader {

    public static Scene readScene(String filePath) {
        Scene scene = new Scene();

        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            dbFactory.setValidating(false);
            dbFactory.setNamespaceAware(true);
            dbFactory.setFeature("http://xml.org/sax/features/namespaces", false);
            dbFactory.setFeature("http://xml.org/sax/features/validation", false);
            dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", false);
            dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

            Document doc =  ParseXml.parse(filePath);
            doc.getDocumentElement().normalize();

            Element root = doc.getDocumentElement();

            // Set output file
            scene.setOutputFile("output/" + root.getAttribute("output_file"));
            System.out.println("Output file: " + scene.getOutputFile());

            // Read background color
            NodeList bgColorList = doc.getElementsByTagName("background_color");
            if (bgColorList.getLength() > 0) {
                Element bgColorElement = (Element) bgColorList.item(0);
                double r = Double.parseDouble(bgColorElement.getAttribute("r"));
                double g = Double.parseDouble(bgColorElement.getAttribute("g"));
                double b = Double.parseDouble(bgColorElement.getAttribute("b"));
                scene.setBackgroundColor(new Color((float) r, (float) g, (float) b));
                System.out.println("Background color: " + r + ", " + g + ", " + b);
            }

            // Read camera
            NodeList cameraList = doc.getElementsByTagName("camera");
            if (cameraList.getLength() > 0) {
                Element cameraElement = (Element) cameraList.item(0);
                Camera camera = readCamera(cameraElement);
                camera.setPosition(new Vec3(0.0, 0.0, 5.0));
                scene.setCamera(camera);
                System.out.println("Camera loaded: " + camera);
            }

            // Read lights
            NodeList lightsList = doc.getElementsByTagName("lights");
            if (lightsList.getLength() > 0) {
                NodeList lightNodes = lightsList.item(0).getChildNodes();
                for (int i = 0; i < lightNodes.getLength(); i++) {
                    Node lightNode = lightNodes.item(i);
                    if (lightNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element lightElement = (Element) lightNode;
                        Light light = readLight(lightElement);
                        scene.addLight(light);
                        System.out.println("Light added: " + light);
                    }
                }
            }

            // Read surfaces
            NodeList surfacesList = doc.getElementsByTagName("surfaces");
            if (surfacesList.getLength() > 0) {
                NodeList surfaceNodes = surfacesList.item(0).getChildNodes();
                for (int i = 0; i < surfaceNodes.getLength(); i++) {
                    Node surfaceNode = surfaceNodes.item(i);
                    if (surfaceNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element surfaceElement = (Element) surfaceNode;
                        Sphere sphere = readSphere(surfaceElement);
                        scene.addSphere(sphere);
                        System.out.println("Sphere added: " + sphere);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return scene;
    }

    private static Camera readCamera(Element cameraElement) {
        Element positionElement = (Element) cameraElement.getElementsByTagName("position").item(0);
        Element lookatElement = (Element) cameraElement.getElementsByTagName("lookat").item(0);
        Element upElement = (Element) cameraElement.getElementsByTagName("up").item(0);
        Element fovElement = (Element) cameraElement.getElementsByTagName("horizontal_fov").item(0);
        Element resolutionElement = (Element) cameraElement.getElementsByTagName("resolution").item(0);
        Element bouncesElement = (Element) cameraElement.getElementsByTagName("max_bounces").item(0);

        Vec3 position = new Vec3(
                Double.parseDouble(positionElement.getAttribute("x")),
                Double.parseDouble(positionElement.getAttribute("y")),
                Double.parseDouble(positionElement.getAttribute("z"))
        );

        Vec3 lookat = new Vec3(
                Double.parseDouble(lookatElement.getAttribute("x")),
                Double.parseDouble(lookatElement.getAttribute("y")),
                Double.parseDouble(lookatElement.getAttribute("z"))
        );

        Vec3 up = new Vec3(
                Double.parseDouble(upElement.getAttribute("x")),
                Double.parseDouble(upElement.getAttribute("y")),
                Double.parseDouble(upElement.getAttribute("z"))
        );

        float fov = (float) Double.parseDouble(fovElement.getAttribute("angle"));
        int width = Integer.parseInt(resolutionElement.getAttribute("horizontal"));
        int height = Integer.parseInt(resolutionElement.getAttribute("vertical"));
        int maxBounces = Integer.parseInt(bouncesElement.getAttribute("n"));

        System.out.println("Camera position: " + position + ", lookat: " + lookat + ", up: " + up);
        System.out.println("Camera fov: " + fov + ", width: " + width + ", height: " + height + ", maxBounces: " + maxBounces);

        return new Camera(position, lookat, up, fov, width, height, maxBounces);
    }


    private static Light readLight(Element lightElement) {
        String tagName = lightElement.getTagName();
        Element colorElement = (Element) lightElement.getElementsByTagName("color").item(0);
        Color color = new Color(
                (float) Double.parseDouble(colorElement.getAttribute("r")),
                (float) Double.parseDouble(colorElement.getAttribute("g")),
                (float) Double.parseDouble(colorElement.getAttribute("b"))
        );

        System.out.println("Light type: " + tagName + ", color: " + color);

        switch (tagName) {
            case "ambient_light":
                return new AmbientLight(color);
            case "point_light":
                Element positionElement = (Element) lightElement.getElementsByTagName("position").item(0);
                Vec3 position = new Vec3(
                        Double.parseDouble(positionElement.getAttribute("x")),
                        Double.parseDouble(positionElement.getAttribute("y")),
                        Double.parseDouble(positionElement.getAttribute("z"))
                );
                System.out.println("Point light position: " + position);
                return new PointLight(color, position);
            case "parallel_light":
                Element directionElement = (Element) lightElement.getElementsByTagName("direction").item(0);
                Vec3 direction = new Vec3(
                        Double.parseDouble(directionElement.getAttribute("x")),
                        Double.parseDouble(directionElement.getAttribute("y")),
                        Double.parseDouble(directionElement.getAttribute("z"))
                );
                System.out.println("Parallel light direction: " + direction);
                return new ParallelLight(color, direction);
            default:
                throw new IllegalArgumentException("Unknown light type: " + tagName);
        }
    }


    private static Sphere readSphere(Element sphereElement) {
        double radius = Double.parseDouble(sphereElement.getAttribute("radius"));

        Element positionElement = (Element) sphereElement.getElementsByTagName("position").item(0);
        Vec3 position = new Vec3(
                Double.parseDouble(positionElement.getAttribute("x")),
                Double.parseDouble(positionElement.getAttribute("y")),
                Double.parseDouble(positionElement.getAttribute("z"))
        );

        Element materialElement = (Element) sphereElement.getElementsByTagName("material_solid").item(0);
        Element colorElement = (Element) materialElement.getElementsByTagName("color").item(0);
        Color color = new Color(
                (float) Double.parseDouble(colorElement.getAttribute("r")),
                (float) Double.parseDouble(colorElement.getAttribute("g")),
                (float) Double.parseDouble(colorElement.getAttribute("b"))
        );

        Element phongElement = (Element) materialElement.getElementsByTagName("phong").item(0);
        float ka = (float) Double.parseDouble(phongElement.getAttribute("ka"));
        float kd = (float) Double.parseDouble(phongElement.getAttribute("kd"));
        float ks = (float) Double.parseDouble(phongElement.getAttribute("ks"));
        float exponent = (float) Double.parseDouble(phongElement.getAttribute("exponent"));

        Material material = new Material(color, ka, kd, ks, exponent);

        System.out.println("Sphere position: " + position + ", radius: " + radius + ", material: " + material);

        return new Sphere(position, (float) radius, material);
    }
}
