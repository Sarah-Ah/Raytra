package com.example.raytracer;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class RayTracer {
    private Scene scene;

    public void renderBlackImage() {
        System.out.println("\n\n===== Rendering Empty Scene =====");

        scene = new Scene();
        scene.setOutputFile("output/blackImage.png");
        scene.setBackgroundColor(new Color(0, 0, 0));

        // Initialize a default camera for the empty scene
        Camera camera = new Camera(new Vec3(0.0, 0.0, 1.0), new Vec3(0.0, 0.0, -1.0), new Vec3(0.0, 1.0, 0.0), 45, 512, 512, 8);
        scene.setCamera(camera);

        renderScene();
    }

    public void renderSpheresScene() {
        System.out.println("\n\n===== Rendering Spheres Scene =====");

        scene = new Scene();
        scene.setOutputFile("output/spheresScene.png");
        scene.setBackgroundColor(new Color(0, 0, 0));

        Camera camera = new Camera(new Vec3(0.0, 0.0, 1.0), new Vec3(0.0, 0.0, -1.0), new Vec3(0.0, 1.0, 0.0), 45, 512, 512, 8);
        scene.setCamera(camera);

        scene.addSphere(new Sphere(new Vec3(-0.8f, 0.8f, -2.0f), 0.3f, new Material(new Color(0, 1, 0), 0.3f, 0.9f, 1.0f, 200))); // Green sphere
        scene.addSphere(new Sphere(new Vec3(0.0f, 0.0f, -2.0f), 0.3f, new Material(new Color(1, 1, 0), 0.3f, 0.9f, 1.0f, 200))); // Yellow sphere
        scene.addSphere(new Sphere(new Vec3(0.8f, -0.8f, -2.0f), 0.3f, new Material(new Color(0.5f, 0, 0.5f), 0.3f, 0.9f, 1.0f, 200))); // Purple sphere

        scene.addLight(new AmbientLight(new Color(0.2f, 0.2f, 0.2f))); // Ambient light
        scene.addLight(new PointLight(new Color(1.0f, 1.0f, 1.0f), new Vec3(-2.0f, -2.0f, 0.0f))); // Point light

        renderScene();
    }

    public void renderFromXML(String filePath) {
        System.out.println("\n\n===== Rendering Scene from XML =====");

        scene = SceneReader.readScene(filePath);
        renderScene();
    }

    private void renderScene() {
        Camera camera = scene.getCamera();
        int imageWidth = camera.getImageWidth();
        int imageHeight = camera.getImageHeight();
        BufferedImage image = new BufferedImage(imageWidth, imageHeight, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < imageHeight; y++) {
            for (int x = 0; x < imageWidth; x++) {
                Ray ray = camera.getRayToPixel(x, y);
                java.awt.Color color = trace(ray).toAwtColor();
                image.setRGB(x, y, color.getRGB());
            }
        }

        try {
            File file = new File(scene.getOutputFile());
            File outputDir = file.getParentFile();
            if (outputDir != null && !outputDir.exists()) {
                outputDir.mkdirs();
            }

            ImageIO.write(image, "png", file);
            System.out.println("Image created successfully: " + scene.getOutputFile());
        } catch (IOException e) {
            System.err.println("Error writing the image file: " + e.getMessage());
        }
    }

    private Color trace(Ray ray) {
        if (scene == null) {
            return new Color(0, 0, 0);  // Return black color if the scene is null
        }

        List<Sphere> spheres = scene.getSpheres();
        Sphere closestSphere = null;
        float closestT = Float.MAX_VALUE;
        Vec3 intersectionPoint = null;
        Vec3 normalAtIntersection = null;

        for (Sphere sphere : spheres) {
            float[] t = new float[1];
            if (sphere.intersect(ray, t) && t[0] < closestT) {
                closestT = t[0];
                closestSphere = sphere;
                intersectionPoint = ray.getOrigin().add(ray.getDirection().scale(t[0]));
                normalAtIntersection = intersectionPoint.subtract(sphere.getCenter()).normalize();
            }
        }

        if (closestSphere != null) {
            return illuminate(ray, intersectionPoint, normalAtIntersection, closestSphere.getMaterial());
        }

        return scene.getBackgroundColor();
    }



    private Color illuminate(Ray ray, Vec3 intersectionPoint, Vec3 normal, Material material) {
        Color ambientColor = new Color(0, 0, 0);
        Color diffuseColor = new Color(0, 0, 0);
        Color specularColor = new Color(0, 0, 0);

        Vec3 viewDir = ray.getDirection().negate().normalize();

        for (Light light : scene.getLights()) {
            if (light instanceof AmbientLight) {
                ambientColor = ambientColor.add(((AmbientLight) light).getColor().multiply(material.getKa()));
            } else if (light instanceof PointLight) {
                PointLight pointLight = (PointLight) light;
                Vec3 lightDir = pointLight.getPosition().subtract(intersectionPoint).normalize();

                // Shadow check
                if (isInShadow(intersectionPoint, pointLight.getPosition())) {
                    continue;
                }

                // Diffuse component
                float diff = Math.max(normal.dot(lightDir), 0.0f);
                diffuseColor = diffuseColor.add(pointLight.getColor().multiply(material.getKd() * diff));

                // Specular component
                Vec3 reflectDir = lightDir.reflect(normal).normalize();
                float spec = (float) Math.pow(Math.max(viewDir.dot(reflectDir), 0.0), material.getExponent());
                specularColor = specularColor.add(pointLight.getColor().multiply(material.getKs() * spec));
            } else if (light instanceof ParallelLight) {
                ParallelLight parallelLight = (ParallelLight) light;
                Vec3 lightDir = parallelLight.getDirection().negate().normalize();

                // Shadow check
                if (isInShadowLight(intersectionPoint, lightDir)) {
                    continue;
                }

                // Diffuse component
                float diff = Math.max(normal.dot(lightDir), 0.0f);
                diffuseColor = diffuseColor.add(parallelLight.getColor().multiply(material.getKd() * diff));

                // Specular component
                Vec3 reflectDir = lightDir.reflect(normal).normalize();
                // Invert the reflection direction for specular calculation
                reflectDir = reflectDir.negate();
                float spec = (float) Math.pow(Math.max(viewDir.dot(reflectDir), 0.0), material.getExponent());
                specularColor = specularColor.add(parallelLight.getColor().multiply(material.getKs() * spec));
            }
        }

        Color finalColor = ambientColor.add(diffuseColor).add(specularColor);
        finalColor = finalColor.multiply(material.getColor());

        return finalColor;
    }


    private boolean isInShadow(Vec3 point, Vec3 lightPosition) {
        Vec3 lightDir = lightPosition.subtract(point).normalize();
        Ray shadowRay = new Ray(point.add(lightDir.scale(0.001f)), lightDir);

        for (Sphere sphere : scene.getSpheres()) {
            float[] t = new float[1];
            if (sphere.intersect(shadowRay, t)) {
                if (t[0] > 0 && t[0] < lightPosition.subtract(point).length()) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isInShadowLight(Vec3 point, Vec3 lightDir) {
        Ray shadowRay = new Ray(point.add(lightDir.scale(0.001f)), lightDir);

        for (Sphere sphere : scene.getSpheres()) {
            float[] t = new float[1];
            if (sphere.intersect(shadowRay, t)) {
                if (t[0] > 0) {
                    return true;
                }
            }
        }
        return false;
    }



}
