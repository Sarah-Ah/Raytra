package com.example.raytracer;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;

public class ParseXml {

    public static Document parse(String filePath) {
        try {
            File file = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            dbFactory.setFeature("http://xml.org/sax/features/validation", false);
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

            // Set up a custom EntityResolver to ignore the DTD
            dBuilder.setEntityResolver(new org.xml.sax.EntityResolver() {
                public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
                    if (systemId.contains("scene.dtd")) {
                        return new InputSource(new StringReader(""));
                    } else {
                        return null;
                    }
                }
            });

            return dBuilder.parse(file);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
